Hi! Welcome to twelfthGear's potion generator V3.X

If you want to run this program, be sure to do the following:
----------------------------------------------------------------------------
1.) How I have the program set up, you need both the program file and the 
    .txt files in the same folder in order for the program to run. 

2.) If you do not have python, you can download it at https://bit.ly/1L2MyD2
    
    Just click Download Python 3.7.X and install accordingly.
    
3.) Once/if you have python installed, double 
    clicking the program file to run it.

4.) Once you have done the previous steps, you can sit back, follow
    the prompt, and enjoy the automation.
----------------------------------------------------------------------------

Sources pulled from:
	Reddit:
		u/twelfthgear:
			My Brain! 
		u/dndspeak:
			https://bit.ly/2OKBhBf

	Elsewhere:
			https://bit.ly/2PuNPtq

	
	